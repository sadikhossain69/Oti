
export const links = [
    {
      name: 'Home',
      path: 'home',
    },
    {
      name: 'About',
      path: 'about',
    },
    
    {
      name: 'Project',
      path: 'project',
    },
    
    {
      name: 'Contact',
      path: 'contact',
    },
  ];
  
  
  
  
  
  
import Image1 from "../../../assets/image/abdur.png";
import Image2 from "../../../assets/image/success_img.png";
import Image3 from "../../../assets/image/success_img.png";


export const Data =[
    {
        id:1,
        image: Image1,
        title: "Jhon Doe",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique facere repellendus dicta facilis cumque"
        
    },
    {
        id:2,
        image: Image2,
        title: "Mr Smith",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique facere repellendus dicta facilis cumque"
        
    },
    {
        id:1,
        image: Image3,
        title: "Webniear Worth",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique facere repellendus dicta facilis cumque"
        
    },
    {
        id:4,
        image: Image1,
        title: "Jhon Doe",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique facere repellendus dicta facilis cumque"
        
    },
    {
        id:5,
        image: Image2,
        title: "Mr Smith",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique facere repellendus dicta facilis cumque"
        
    },
    {
        id:6,
        image: Image3,
        title: "Webniear Worth",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique facere repellendus dicta facilis cumque"
        
    },

]
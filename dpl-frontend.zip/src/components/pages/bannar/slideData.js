import banner1 from '../../../assets/image/banner.jpeg'
import banner2 from '../../../assets/image/banner1.jpeg'

export const slideData = [
    {
        id: 1,
        slideHeader: "Make your Home, Afford your Dream",
        slideDetail: "lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's .",
        slideBgImage: banner1,
        slideDetailLink: "/about"
    },
    {
        id: 2,
        slideHeader: "Make your Home, Afford your Dream",
        slideDetail: "lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's .",
        slideBgImage: banner2,
        slideDetailLink: "/about"
    },
    {
        id: 3,
        slideHeader: "Make your Home, Afford your Dream",
        slideDetail: "lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's .",
        slideBgImage: banner1,
        slideDetailLink: "/about"
    },
]